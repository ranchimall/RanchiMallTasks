<?php
/**
 * Created by PhpStorm.
 * Date: 10/5/2017
 * Time: 11:19 AM
 */
?>

    <div class="container">
        <div class="col-lg-12">
            <h2 class="mt--2">My Messages</h2>
            <div class="table-responsive mt--2">
                <table class="table table-striped table-bordered" id="messages-datatable" cellspacing="0" width="100%" cellpadding="10">
                    <thead>
                    <tr>
                        <th>Order No.</th>
                        <th>Message</th>
                        <th>Date</th>
                    </tr>
                    </thead>
                    <tbody id="myMessagesTable"></tbody>
                </table>
            </div>
        </div>
    </div>

